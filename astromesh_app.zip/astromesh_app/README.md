# AstroMesh

AstroMesh is a Python application and MCP server that combines:

- **Free Astrology API** data for birth charts and horoscopes
- **OpenWeatherMap** current weather data
- A recommendation layer that blends astrological context with real-world weather conditions
- A **Model Context Protocol (MCP)** server so other AI agents can call the tools

> Astrology output is intended for reflection and entertainment. Weather safety should always be checked against official local alerts.

## Project structure

```text
astromesh_app/
├── app.py              # Core clients, models, recommendation logic, and CLI
├── mcp_server.py       # MCP tools for agents
├── requirements.txt    # Python dependencies
├── .env.example        # Environment variable template
└── README.md           # Setup and usage
```

## Requirements

- Python 3.10+
- A Free Astrology API key from <https://freeastrologyapi.com>
- An OpenWeatherMap API key from <https://openweathermap.org/api>

## Setup

```bash
git clone <your-repo-url> astromesh_app
cd astromesh_app

python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

pip install -r requirements.txt
cp .env.example .env
```

Edit `.env`:

```bash
FREE_ASTROLOGY_API_KEY=your_free_astrology_api_key
OPENWEATHER_API_KEY=your_openweathermap_api_key
```

Optional endpoint overrides are available in `.env.example`. These are useful because Free Astrology API endpoint paths can vary by account/product version.

## Environment variables

| Variable | Required | Description |
| --- | --- | --- |
| `FREE_ASTROLOGY_API_KEY` | Yes | API key for Free Astrology API. Sent as `x-api-key`. |
| `OPENWEATHER_API_KEY` | Yes | API key for OpenWeatherMap. |
| `FREE_ASTROLOGY_BASE_URL` | No | Defaults to `https://json.freeastrologyapi.com`. |
| `FREE_ASTROLOGY_BIRTH_CHART_PATH` | No | Defaults to `/western/natal-chart`. |
| `FREE_ASTROLOGY_HOROSCOPE_PATH` | No | Defaults to `/horoscope/daily/{sign}`. Supports `{sign}` and `{day}` placeholders. |
| `OPENWEATHER_BASE_URL` | No | Defaults to `https://api.openweathermap.org`. |
| `ASTROMESH_TIMEOUT_SECONDS` | No | HTTP timeout. Defaults to `20`. |
| `ASTROMESH_LOG_LEVEL` | No | Logging level. Defaults to `INFO`. |

## CLI usage

### Get current weather

```bash
python app.py weather --city "London" --units metric
```

or with coordinates:

```bash
python app.py weather --lat 51.5072 --lon -0.1276 --units metric
```

### Get a horoscope

```bash
python app.py horoscope --sign leo --day today
```

### Get a birth chart

```bash
python app.py birth-chart \
  --year 1992 \
  --month 8 \
  --day 14 \
  --hours 9 \
  --minutes 30 \
  --lat 40.7128 \
  --lon -74.0060 \
  --timezone -4 \
  --name "Example Person"
```

### Get combined astro-weather insights

```bash
python app.py insight --sign leo --city "New York,US" --units imperial
```

The output includes:

- normalized weather summary
- horoscope API payload
- zodiac element
- weather tags
- practical personalized recommendations
- wellness notes
- activity ideas

## MCP server usage

Start the MCP server over stdio:

```bash
python mcp_server.py
```

### Example MCP client configuration

For Claude Desktop or another MCP-compatible client, add a server entry similar to:

```json
{
  "mcpServers": {
    "astromesh": {
      "command": "python",
      "args": ["/absolute/path/to/astromesh_app/mcp_server.py"],
      "env": {
        "FREE_ASTROLOGY_API_KEY": "your_free_astrology_api_key",
        "OPENWEATHER_API_KEY": "your_openweathermap_api_key"
      }
    }
  }
}
```

If you use a virtual environment, point `command` to the virtual environment Python executable.

## MCP tools

### `zodiac_sign_from_birth_date`

Calculate a tropical sun sign from month/day.

```json
{
  "month": 8,
  "day": 14
}
```

### `get_birth_chart`

Fetch a birth chart from Free Astrology API.

```json
{
  "year": 1992,
  "month": 8,
  "day": 14,
  "hours": 9,
  "minutes": 30,
  "seconds": 0,
  "latitude": 40.7128,
  "longitude": -74.006,
  "timezone": -4,
  "name": "Example Person"
}
```

### `get_horoscope`

Fetch a horoscope from Free Astrology API.

```json
{
  "sign": "leo",
  "day": "today"
}
```

### `get_weather`

Fetch current OpenWeatherMap weather.

```json
{
  "city": "New York,US",
  "units": "imperial"
}
```

or:

```json
{
  "latitude": 40.7128,
  "longitude": -74.006,
  "units": "metric"
}
```

### `get_combined_insights`

Combine weather, horoscope, zodiac element, and recommendation logic.

```json
{
  "sign": "leo",
  "city": "New York,US",
  "units": "imperial"
}
```

With birth-date sign derivation:

```json
{
  "city": "Lisbon,PT",
  "units": "metric",
  "birth_month": 3,
  "birth_day": 4
}
```

With a full optional birth chart:

```json
{
  "city": "Lisbon,PT",
  "units": "metric",
  "birth_year": 1990,
  "birth_month": 3,
  "birth_day": 4,
  "birth_hours": 6,
  "birth_minutes": 15,
  "birth_latitude": 38.7223,
  "birth_longitude": -9.1393,
  "birth_timezone": 0,
  "include_birth_chart": true
}
```

## Python library usage

```python
from app import AstroMeshApp, CombinedInsightRequest

with AstroMeshApp() as app:
    result = app.get_combined_insights(
        CombinedInsightRequest(sign="aquarius", city="Seattle,US", units="imperial")
    )
    print(result["insights"]["headline"])
```

## Notes on Free Astrology API endpoints

The application defaults to:

- birth chart: `POST https://json.freeastrologyapi.com/western/natal-chart`
- horoscope: `GET https://json.freeastrologyapi.com/horoscope/daily/{sign}`

If your Free Astrology API account uses different endpoint paths, set:

```bash
FREE_ASTROLOGY_BIRTH_CHART_PATH=/your/birth-chart/path
FREE_ASTROLOGY_HOROSCOPE_PATH=/your/horoscope/path/{sign}
```

The horoscope client tries `GET` first and falls back to `POST` on `404` or `405`.

## Error handling

- Missing API keys raise a `ConfigurationError`.
- Upstream HTTP errors are returned with status code and response snippet.
- MCP tools return structured payloads:

```json
{
  "ok": false,
  "error": {
    "type": "ConfigurationError",
    "message": "Missing required environment variable(s): ..."
  }
}
```

## Development

Format and type-checking tools are intentionally not pinned, but the code is structured for:

```bash
python -m compileall app.py mcp_server.py
python app.py --help
```

Recommended future improvements:

- Add unit tests with mocked HTTP responses.
- Add caching for repeated horoscope/weather calls.
- Add geocoding convenience helpers.
- Add official weather alert integration.
