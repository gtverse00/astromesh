#!/usr/bin/env python3
"""
AstroMesh MCP server.

Run this file with an MCP-compatible client over stdio:

    python mcp_server.py

The server exposes:
    - get_birth_chart
    - get_horoscope
    - get_weather
    - get_combined_insights
    - zodiac_sign_from_birth_date

Configuration is read from the same environment variables used by app.py.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from mcp.server.fastmcp import FastMCP

from app import (
    AstroMeshApp,
    AstroMeshError,
    BirthChartRequest,
    CombinedInsightRequest,
    HoroscopeRequest,
    WeatherRequest,
    zodiac_sign_from_date,
)


LOGGER = logging.getLogger("astromesh.mcp")
mcp = FastMCP(
    "AstroMesh",
    instructions=(
        "AstroMesh provides astrology, weather, and combined astro-weather "
        "recommendation tools. All tools return JSON-serializable dictionaries."
    ),
)


def _error_payload(exc: Exception) -> Dict[str, Any]:
    """Convert exceptions into MCP-friendly structured errors."""
    LOGGER.exception("AstroMesh MCP tool error")
    return {
        "ok": False,
        "error": {
            "type": exc.__class__.__name__,
            "message": str(exc),
        },
    }


@mcp.tool()
def zodiac_sign_from_birth_date(month: int, day: int) -> Dict[str, Any]:
    """
    Calculate the tropical zodiac sun sign from month and day.

    Args:
        month: Month number, 1-12.
        day: Day of month, 1-31.

    Returns:
        A dictionary with ok=true and sign, or ok=false and an error payload.
    """
    try:
        return {"ok": True, "sign": zodiac_sign_from_date(month, day)}
    except Exception as exc:  # MCP tools should not leak tracebacks to clients.
        return _error_payload(exc)


@mcp.tool()
def get_birth_chart(
    year: int,
    month: int,
    day: int,
    hours: int,
    minutes: int,
    latitude: float,
    longitude: float,
    timezone: float,
    seconds: int = 0,
    name: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Get a birth/natal chart from Free Astrology API.

    Args:
        year: Birth year.
        month: Birth month, 1-12.
        day: Birth day of month, 1-31.
        hours: Birth hour in local time, 0-23.
        minutes: Birth minute, 0-59.
        seconds: Birth second, 0-59.
        latitude: Birthplace latitude.
        longitude: Birthplace longitude.
        timezone: Timezone offset from UTC at birth, e.g. -5.0 or 5.5.
        name: Optional person name.

    Returns:
        A JSON-serializable birth chart response wrapped in {"ok": true, "data": ...}.
    """
    try:
        request = BirthChartRequest(
            year=year,
            month=month,
            date=day,
            hours=hours,
            minutes=minutes,
            seconds=seconds,
            latitude=latitude,
            longitude=longitude,
            timezone=timezone,
            name=name,
        )
        with AstroMeshApp() as app:
            return {"ok": True, "data": app.get_birth_chart(request)}
    except (AstroMeshError, ValueError) as exc:
        return _error_payload(exc)


@mcp.tool()
def get_horoscope(sign: str, day: str = "today") -> Dict[str, Any]:
    """
    Get a daily horoscope from Free Astrology API.

    Args:
        sign: Zodiac sign, e.g. aries, taurus, gemini.
        day: yesterday, today, or tomorrow.

    Returns:
        A JSON-serializable horoscope response wrapped in {"ok": true, "data": ...}.
    """
    try:
        request = HoroscopeRequest(sign=sign, day=day)  # type: ignore[arg-type]
        with AstroMeshApp() as app:
            return {"ok": True, "data": app.get_horoscope(request)}
    except (AstroMeshError, ValueError) as exc:
        return _error_payload(exc)


@mcp.tool()
def get_weather(
    city: Optional[str] = None,
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    units: str = "metric",
) -> Dict[str, Any]:
    """
    Get current weather from OpenWeatherMap.

    Provide either city or both latitude and longitude.

    Args:
        city: City name such as "London" or "Austin,US".
        latitude: Latitude if city is not provided.
        longitude: Longitude if city is not provided.
        units: standard, metric, or imperial.

    Returns:
        A JSON-serializable OpenWeatherMap response wrapped in {"ok": true, "data": ...}.
    """
    try:
        request = WeatherRequest(
            city=city,
            latitude=latitude,
            longitude=longitude,
            units=units,  # type: ignore[arg-type]
        )
        with AstroMeshApp() as app:
            return {"ok": True, "data": app.get_weather(request)}
    except (AstroMeshError, ValueError) as exc:
        return _error_payload(exc)


@mcp.tool()
def get_combined_insights(
    city: Optional[str] = None,
    sign: Optional[str] = None,
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    units: str = "metric",
    birth_year: Optional[int] = None,
    birth_month: Optional[int] = None,
    birth_day: Optional[int] = None,
    birth_hours: Optional[int] = None,
    birth_minutes: Optional[int] = None,
    birth_seconds: int = 0,
    birth_latitude: Optional[float] = None,
    birth_longitude: Optional[float] = None,
    birth_timezone: Optional[float] = None,
    include_birth_chart: bool = False,
) -> Dict[str, Any]:
    """
    Get combined astrology + weather recommendations.

    You must provide:
      - weather location as city OR latitude+longitude
      - zodiac context as sign OR a full/partial birth date

    If sign is omitted and birth_month/birth_day are provided, AstroMesh derives
    the tropical sun sign from the date. If include_birth_chart=true, all birth
    chart fields are required and Free Astrology API will be called for the chart.

    Args:
        city: Weather city, e.g. "Paris" or "New York,US".
        sign: Optional zodiac sign.
        latitude: Weather latitude.
        longitude: Weather longitude.
        units: standard, metric, or imperial.
        birth_year: Birth year for optional chart.
        birth_month: Birth month.
        birth_day: Birth day of month.
        birth_hours: Birth hour.
        birth_minutes: Birth minute.
        birth_seconds: Birth second.
        birth_latitude: Birthplace latitude.
        birth_longitude: Birthplace longitude.
        birth_timezone: Birth timezone offset from UTC.
        include_birth_chart: Include full chart response in output.

    Returns:
        Combined weather summary, horoscope payload, and recommendations.
    """
    try:
        birth_chart_request: Optional[BirthChartRequest] = None
        if any(
            value is not None
            for value in [
                birth_year,
                birth_month,
                birth_day,
                birth_hours,
                birth_minutes,
                birth_latitude,
                birth_longitude,
                birth_timezone,
            ]
        ):
            # If only month/day are supplied, this object is not necessary unless
            # include_birth_chart is requested. For full chart calls, require all.
            if include_birth_chart:
                missing = [
                    field
                    for field, value in {
                        "birth_year": birth_year,
                        "birth_month": birth_month,
                        "birth_day": birth_day,
                        "birth_hours": birth_hours,
                        "birth_minutes": birth_minutes,
                        "birth_latitude": birth_latitude,
                        "birth_longitude": birth_longitude,
                        "birth_timezone": birth_timezone,
                    }.items()
                    if value is None
                ]
                if missing:
                    raise ValueError(
                        "include_birth_chart=true requires: " + ", ".join(missing)
                    )

            if all(
                value is not None
                for value in [
                    birth_year,
                    birth_month,
                    birth_day,
                    birth_hours,
                    birth_minutes,
                    birth_latitude,
                    birth_longitude,
                    birth_timezone,
                ]
            ):
                birth_chart_request = BirthChartRequest(
                    year=birth_year,  # type: ignore[arg-type]
                    month=birth_month,  # type: ignore[arg-type]
                    date=birth_day,  # type: ignore[arg-type]
                    hours=birth_hours,  # type: ignore[arg-type]
                    minutes=birth_minutes,  # type: ignore[arg-type]
                    seconds=birth_seconds,
                    latitude=birth_latitude,  # type: ignore[arg-type]
                    longitude=birth_longitude,  # type: ignore[arg-type]
                    timezone=birth_timezone,  # type: ignore[arg-type]
                )

        resolved_sign = sign
        if not resolved_sign and birth_month is not None and birth_day is not None:
            resolved_sign = zodiac_sign_from_date(birth_month, birth_day)

        request = CombinedInsightRequest(
            sign=resolved_sign,
            birth_chart=birth_chart_request,
            city=city,
            latitude=latitude,
            longitude=longitude,
            units=units,  # type: ignore[arg-type]
            include_birth_chart=include_birth_chart,
        )
        with AstroMeshApp() as app:
            return {"ok": True, "data": app.get_combined_insights(request)}
    except (AstroMeshError, ValueError) as exc:
        return _error_payload(exc)


if __name__ == "__main__":
    # FastMCP defaults to stdio, which is what most local MCP clients expect.
    mcp.run()
