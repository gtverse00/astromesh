#!/usr/bin/env python3
"""
AstroMesh core application.

AstroMesh combines astrology data from Free Astrology API with current weather
data from OpenWeatherMap and produces personalized, practical recommendations.

Environment variables:
    FREE_ASTROLOGY_API_KEY       Required for Free Astrology API calls.
    OPENWEATHER_API_KEY          Required for OpenWeatherMap calls.
    FREE_ASTROLOGY_BASE_URL      Optional. Defaults to https://json.freeastrologyapi.com
    FREE_ASTROLOGY_BIRTH_CHART_PATH Optional. Defaults to /western/natal-chart
    FREE_ASTROLOGY_HOROSCOPE_PATH   Optional. Defaults to /horoscope/daily/{sign}
    OPENWEATHER_BASE_URL         Optional. Defaults to https://api.openweathermap.org
    ASTROMESH_TIMEOUT_SECONDS    Optional. Defaults to 20.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Dict, List, Literal, Optional, Tuple

import httpx
from dotenv import load_dotenv
from pydantic import BaseModel, Field, field_validator


load_dotenv()

LOGGER = logging.getLogger("astromesh")
logging.basicConfig(
    level=os.getenv("ASTROMESH_LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)


ZODIAC_SIGNS = {
    "aries",
    "taurus",
    "gemini",
    "cancer",
    "leo",
    "virgo",
    "libra",
    "scorpio",
    "sagittarius",
    "capricorn",
    "aquarius",
    "pisces",
}

SIGN_ELEMENTS = {
    "aries": "fire",
    "leo": "fire",
    "sagittarius": "fire",
    "taurus": "earth",
    "virgo": "earth",
    "capricorn": "earth",
    "gemini": "air",
    "libra": "air",
    "aquarius": "air",
    "cancer": "water",
    "scorpio": "water",
    "pisces": "water",
}

ELEMENT_THEMES = {
    "fire": {
        "focus": "motivation, courage, visible action",
        "watchout": "avoid rushing, overheating, and taking unnecessary risks",
    },
    "earth": {
        "focus": "stability, practical planning, body care",
        "watchout": "avoid rigidity and overcommitting to routines that do not fit today",
    },
    "air": {
        "focus": "communication, learning, networking",
        "watchout": "avoid scattering your attention across too many plans",
    },
    "water": {
        "focus": "intuition, recovery, emotional intelligence",
        "watchout": "avoid absorbing the mood of the environment without boundaries",
    },
}


class AstroMeshError(Exception):
    """Base exception for AstroMesh errors."""


class ConfigurationError(AstroMeshError):
    """Raised when required configuration is missing."""


class ExternalAPIError(AstroMeshError):
    """Raised when an upstream API returns an error or malformed response."""


@dataclass(frozen=True)
class AstroMeshConfig:
    """Application configuration loaded from environment variables."""

    free_astrology_api_key: str
    openweather_api_key: str
    free_astrology_base_url: str = "https://json.freeastrologyapi.com"
    free_astrology_birth_chart_path: str = "/western/natal-chart"
    free_astrology_horoscope_path: str = "/horoscope/daily/{sign}"
    openweather_base_url: str = "https://api.openweathermap.org"
    timeout_seconds: float = 20.0

    @classmethod
    def from_env(cls) -> "AstroMeshConfig":
        """Build configuration from process environment."""
        free_astrology_api_key = os.getenv("FREE_ASTROLOGY_API_KEY", "").strip()
        openweather_api_key = os.getenv("OPENWEATHER_API_KEY", "").strip()

        missing = []
        if not free_astrology_api_key:
            missing.append("FREE_ASTROLOGY_API_KEY")
        if not openweather_api_key:
            missing.append("OPENWEATHER_API_KEY")
        if missing:
            raise ConfigurationError(
                "Missing required environment variable(s): " + ", ".join(missing)
            )

        timeout_raw = os.getenv("ASTROMESH_TIMEOUT_SECONDS", "20").strip()
        try:
            timeout_seconds = float(timeout_raw)
        except ValueError as exc:
            raise ConfigurationError(
                "ASTROMESH_TIMEOUT_SECONDS must be a number"
            ) from exc

        return cls(
            free_astrology_api_key=free_astrology_api_key,
            openweather_api_key=openweather_api_key,
            free_astrology_base_url=os.getenv(
                "FREE_ASTROLOGY_BASE_URL", cls.free_astrology_base_url
            ).rstrip("/"),
            free_astrology_birth_chart_path=os.getenv(
                "FREE_ASTROLOGY_BIRTH_CHART_PATH", cls.free_astrology_birth_chart_path
            ),
            free_astrology_horoscope_path=os.getenv(
                "FREE_ASTROLOGY_HOROSCOPE_PATH", cls.free_astrology_horoscope_path
            ),
            openweather_base_url=os.getenv(
                "OPENWEATHER_BASE_URL", cls.openweather_base_url
            ).rstrip("/"),
            timeout_seconds=timeout_seconds,
        )


class BirthChartRequest(BaseModel):
    """Input model for a natal chart request."""

    year: int = Field(..., ge=1800, le=2200)
    month: int = Field(..., ge=1, le=12)
    date: int = Field(..., ge=1, le=31, description="Day of month.")
    hours: int = Field(..., ge=0, le=23)
    minutes: int = Field(..., ge=0, le=59)
    seconds: int = Field(default=0, ge=0, le=59)
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)
    timezone: float = Field(
        ..., description="Timezone offset from UTC, e.g. -5.0 or 5.5."
    )
    name: Optional[str] = Field(default=None, description="Optional person name.")
    settings: Dict[str, Any] = Field(
        default_factory=lambda: {
            "observation_point": "topocentric",
            "ayanamsha": "tropical",
        }
    )

    def to_free_astrology_payload(self) -> Dict[str, Any]:
        """Return the payload shape expected by Free Astrology API."""
        payload = self.model_dump(exclude_none=True)
        # The API examples use "date" for day of month; keep it unchanged.
        return payload


class HoroscopeRequest(BaseModel):
    """Input model for a horoscope request."""

    sign: str
    day: Optional[Literal["yesterday", "today", "tomorrow"]] = "today"

    @field_validator("sign")
    @classmethod
    def normalize_sign(cls, value: str) -> str:
        normalized = value.strip().lower()
        if normalized not in ZODIAC_SIGNS:
            raise ValueError(f"Unsupported zodiac sign: {value!r}")
        return normalized


class WeatherRequest(BaseModel):
    """Input model for a weather request."""

    city: Optional[str] = None
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)
    units: Literal["standard", "metric", "imperial"] = "metric"
    language: str = "en"

    @field_validator("city")
    @classmethod
    def strip_city(cls, value: Optional[str]) -> Optional[str]:
        return value.strip() if isinstance(value, str) and value.strip() else None

    def validate_location(self) -> None:
        if not self.city and (self.latitude is None or self.longitude is None):
            raise ValueError("Provide either city or both latitude and longitude.")


class CombinedInsightRequest(BaseModel):
    """Input model for combined astrology + weather insight."""

    sign: Optional[str] = None
    birth_chart: Optional[BirthChartRequest] = None
    city: Optional[str] = None
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)
    units: Literal["standard", "metric", "imperial"] = "metric"
    include_birth_chart: bool = False

    @field_validator("sign")
    @classmethod
    def normalize_optional_sign(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        normalized = value.strip().lower()
        if normalized not in ZODIAC_SIGNS:
            raise ValueError(f"Unsupported zodiac sign: {value!r}")
        return normalized

    def resolve_sign(self) -> str:
        """Resolve zodiac sign from explicit sign or birth date."""
        if self.sign:
            return self.sign
        if self.birth_chart:
            return zodiac_sign_from_date(self.birth_chart.month, self.birth_chart.date)
        raise ValueError("Provide sign or birth_chart to resolve the zodiac sign.")


def zodiac_sign_from_date(month: int, day: int) -> str:
    """
    Calculate tropical sun sign from month/day.

    This is used as a convenience fallback for horoscope requests and does not
    replace a full chart calculation.
    """
    boundaries: List[Tuple[str, Tuple[int, int], Tuple[int, int]]] = [
        ("capricorn", (12, 22), (1, 19)),
        ("aquarius", (1, 20), (2, 18)),
        ("pisces", (2, 19), (3, 20)),
        ("aries", (3, 21), (4, 19)),
        ("taurus", (4, 20), (5, 20)),
        ("gemini", (5, 21), (6, 20)),
        ("cancer", (6, 21), (7, 22)),
        ("leo", (7, 23), (8, 22)),
        ("virgo", (8, 23), (9, 22)),
        ("libra", (9, 23), (10, 22)),
        ("scorpio", (10, 23), (11, 21)),
        ("sagittarius", (11, 22), (12, 21)),
    ]

    def after_or_equal(a: Tuple[int, int], b: Tuple[int, int]) -> bool:
        return a[0] > b[0] or (a[0] == b[0] and a[1] >= b[1])

    def before_or_equal(a: Tuple[int, int], b: Tuple[int, int]) -> bool:
        return a[0] < b[0] or (a[0] == b[0] and a[1] <= b[1])

    value = (month, day)
    for sign, start, end in boundaries:
        if start[0] <= end[0]:
            if after_or_equal(value, start) and before_or_equal(value, end):
                return sign
        else:
            # Ranges crossing year boundary, e.g. Capricorn.
            if after_or_equal(value, start) or before_or_equal(value, end):
                return sign
    raise ValueError(f"Invalid month/day: {month}/{day}")


class FreeAstrologyClient:
    """HTTP client for Free Astrology API."""

    def __init__(self, config: AstroMeshConfig):
        self.config = config
        self._client = httpx.Client(timeout=config.timeout_seconds)

    def close(self) -> None:
        self._client.close()

    def _url(self, path: str) -> str:
        clean_path = path if path.startswith("/") else f"/{path}"
        return f"{self.config.free_astrology_base_url}{clean_path}"

    def _headers(self) -> Dict[str, str]:
        return {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "x-api-key": self.config.free_astrology_api_key,
        }

    def _handle_response(self, response: httpx.Response, service: str) -> Dict[str, Any]:
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            body = exc.response.text[:1000] if exc.response is not None else ""
            raise ExternalAPIError(
                f"{service} returned HTTP {exc.response.status_code}: {body}"
            ) from exc

        try:
            return response.json()
        except ValueError as exc:
            raise ExternalAPIError(f"{service} returned non-JSON response") from exc

    def birth_chart(self, request: BirthChartRequest) -> Dict[str, Any]:
        """Fetch a natal/birth chart from Free Astrology API."""
        url = self._url(self.config.free_astrology_birth_chart_path)
        payload = request.to_free_astrology_payload()
        LOGGER.debug("Requesting birth chart from Free Astrology API: %s", url)
        response = self._client.post(url, headers=self._headers(), json=payload)
        return self._handle_response(response, "Free Astrology API birth chart")

    def horoscope(self, request: HoroscopeRequest) -> Dict[str, Any]:
        """
        Fetch a horoscope from Free Astrology API.

        The default path is configurable because Free Astrology API may expose
        horoscope endpoints differently depending on product/version. The path
        may include "{sign}" and "{day}" placeholders.
        """
        path = self.config.free_astrology_horoscope_path.format(
            sign=request.sign, day=request.day or "today"
        )
        url = self._url(path)
        payload = {"sign": request.sign, "day": request.day or "today"}

        LOGGER.debug("Requesting horoscope from Free Astrology API: %s", url)

        # Most horoscope endpoints use GET, but some API variants accept POST.
        # Try GET first, then retry with POST if the endpoint rejects the method.
        response = self._client.get(url, headers=self._headers(), params=payload)
        if response.status_code in {404, 405}:
            response = self._client.post(url, headers=self._headers(), json=payload)

        return self._handle_response(response, "Free Astrology API horoscope")


class OpenWeatherClient:
    """HTTP client for OpenWeatherMap current weather API."""

    def __init__(self, config: AstroMeshConfig):
        self.config = config
        self._client = httpx.Client(timeout=config.timeout_seconds)

    def close(self) -> None:
        self._client.close()

    def current_weather(self, request: WeatherRequest) -> Dict[str, Any]:
        """Fetch current weather by city or latitude/longitude."""
        request.validate_location()
        url = f"{self.config.openweather_base_url}/data/2.5/weather"
        params: Dict[str, Any] = {
            "appid": self.config.openweather_api_key,
            "units": request.units,
            "lang": request.language,
        }
        if request.city:
            params["q"] = request.city
        else:
            params["lat"] = request.latitude
            params["lon"] = request.longitude

        LOGGER.debug("Requesting weather from OpenWeatherMap: %s", url)
        response = self._client.get(url, params=params)

        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            body = exc.response.text[:1000] if exc.response is not None else ""
            raise ExternalAPIError(
                f"OpenWeatherMap returned HTTP {exc.response.status_code}: {body}"
            ) from exc

        try:
            return response.json()
        except ValueError as exc:
            raise ExternalAPIError("OpenWeatherMap returned non-JSON response") from exc


class AstroWeatherAnalyzer:
    """Business logic for blending astrology with weather context."""

    @staticmethod
    def summarize_weather(weather: Dict[str, Any], units: str = "metric") -> Dict[str, Any]:
        """Extract a compact weather summary from OpenWeatherMap response."""
        condition = {}
        if isinstance(weather.get("weather"), list) and weather["weather"]:
            condition = weather["weather"][0] or {}

        main = weather.get("main") or {}
        wind = weather.get("wind") or {}
        clouds = weather.get("clouds") or {}

        unit_suffix = {"metric": "°C", "imperial": "°F", "standard": "K"}.get(units, "")

        return {
            "location": weather.get("name"),
            "country": (weather.get("sys") or {}).get("country"),
            "condition": condition.get("main"),
            "description": condition.get("description"),
            "temperature": main.get("temp"),
            "feels_like": main.get("feels_like"),
            "humidity": main.get("humidity"),
            "pressure": main.get("pressure"),
            "wind_speed": wind.get("speed"),
            "cloudiness": clouds.get("all"),
            "units": units,
            "temperature_unit": unit_suffix,
            "observed_at_utc": datetime.utcfromtimestamp(weather.get("dt", 0)).isoformat()
            + "Z"
            if weather.get("dt")
            else None,
        }

    @staticmethod
    def extract_horoscope_text(horoscope: Dict[str, Any]) -> Optional[str]:
        """Best-effort extraction of human-readable horoscope text."""
        possible_keys = [
            "prediction",
            "horoscope",
            "description",
            "content",
            "text",
            "daily_horoscope",
            "summary",
        ]
        for key in possible_keys:
            value = horoscope.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()

        # Some APIs wrap data inside "data".
        data = horoscope.get("data")
        if isinstance(data, dict):
            for key in possible_keys:
                value = data.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()

        return None

    @staticmethod
    def weather_tags(weather_summary: Dict[str, Any]) -> List[str]:
        """Classify weather into recommendation tags."""
        tags: List[str] = []
        condition = (weather_summary.get("condition") or "").lower()
        description = (weather_summary.get("description") or "").lower()

        temp = weather_summary.get("temperature")
        humidity = weather_summary.get("humidity")
        wind_speed = weather_summary.get("wind_speed")
        cloudiness = weather_summary.get("cloudiness")

        if any(token in condition or token in description for token in ["rain", "drizzle", "thunderstorm"]):
            tags.append("wet")
        if "snow" in condition or "snow" in description:
            tags.append("snow")
        if any(token in condition or token in description for token in ["clear", "sun"]):
            tags.append("sunny")
        if "cloud" in condition or "cloud" in description:
            tags.append("cloudy")
        if "mist" in description or "fog" in description or "haze" in description:
            tags.append("low_visibility")

        if isinstance(temp, (int, float)):
            if temp >= 30:
                tags.append("hot")
            elif temp <= 5:
                tags.append("cold")
            elif 18 <= temp <= 26:
                tags.append("mild")

        if isinstance(humidity, (int, float)) and humidity >= 80:
            tags.append("humid")

        if isinstance(wind_speed, (int, float)) and wind_speed >= 10:
            tags.append("windy")

        if isinstance(cloudiness, (int, float)) and cloudiness >= 75:
            tags.append("overcast")

        return tags

    @staticmethod
    def generate_recommendations(
        sign: str,
        weather_summary: Dict[str, Any],
        horoscope: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Generate personalized recommendations from sign, horoscope, and weather."""
        sign = sign.lower()
        element = SIGN_ELEMENTS.get(sign, "unknown")
        themes = ELEMENT_THEMES.get(
            element,
            {"focus": "self-awareness", "watchout": "avoid autopilot decisions"},
        )
        tags = AstroWeatherAnalyzer.weather_tags(weather_summary)
        horoscope_text = AstroWeatherAnalyzer.extract_horoscope_text(horoscope)

        recommendations: List[str] = []
        activity_ideas: List[str] = []
        wellness_notes: List[str] = []

        # Weather first: practical and safety-aware.
        if "wet" in tags:
            recommendations.append(
                "Carry rain protection and choose flexible plans; water in the forecast favors reflection over rushing."
            )
            activity_ideas.append("Journal, plan, or handle indoor creative work.")
        if "thunderstorm" in tags:
            recommendations.append(
                "Avoid exposed outdoor activities and give yourself extra travel time."
            )
        if "snow" in tags:
            recommendations.append(
                "Prioritize warmth, traction, and schedule buffers; do not force low-priority errands."
            )
            activity_ideas.append("Choose grounded indoor tasks and restorative rituals.")
        if "hot" in tags:
            recommendations.append(
                "Hydrate early, schedule demanding tasks outside peak heat, and avoid emotional overexertion."
            )
            wellness_notes.append("Use cooling breaks and lighter meals.")
        if "cold" in tags:
            recommendations.append(
                "Protect your energy with layers, warm food, and a slower start."
            )
            wellness_notes.append("Warm up joints and muscles before intense activity.")
        if "windy" in tags:
            recommendations.append(
                "Keep plans adaptable; windy weather pairs well with brainstorming but not overcommitting."
            )
        if "sunny" in tags:
            recommendations.append(
                "Use the brighter conditions for visible progress, outreach, or a mood-lifting walk."
            )
            activity_ideas.append("Take a mindful walk or schedule an energizing conversation.")
        if "overcast" in tags or "cloudy" in tags:
            recommendations.append(
                "Lean into steady work and simplify decisions; cloudy skies reward focus over spectacle."
            )

        # Element-specific blending.
        if element == "fire":
            if "hot" in tags:
                recommendations.append(
                    f"As a {sign.title()} fire sign, channel drive carefully today: act decisively, but pace your body."
                )
            elif "wet" in tags or "overcast" in tags:
                recommendations.append(
                    f"Your fire-sign momentum may feel muted; choose one bold action rather than forcing ten."
                )
            else:
                recommendations.append(
                    f"Your fire element supports courage today; pick a goal that benefits from direct action."
                )
            activity_ideas.append("Do a short, high-intention workout or launch a small initiative.")
        elif element == "earth":
            if "wet" in tags or "snow" in tags:
                recommendations.append(
                    f"As an earth sign, use the weather as permission to consolidate, budget, cook, or organize."
                )
            elif "sunny" in tags:
                recommendations.append(
                    "Ground your plans outdoors if possible: sunlight can make practical tasks feel lighter."
                )
            else:
                recommendations.append(
                    "Your earth element benefits from a clear checklist and one tangible result."
                )
            activity_ideas.append("Tidy a workspace, prepare meals, or complete a practical errand.")
        elif element == "air":
            if "windy" in tags:
                recommendations.append(
                    f"Air-sign energy is amplified by wind: capture ideas, but verify details before acting."
                )
            elif "low_visibility" in tags or "overcast" in tags:
                recommendations.append(
                    "Clarify messages and avoid assumptions; low-visibility weather mirrors communication fog."
                )
            else:
                recommendations.append(
                    "Your air element favors conversation, writing, study, and social connection."
                )
            activity_ideas.append("Schedule a check-in, brainstorm, write, or learn something new.")
        elif element == "water":
            if "wet" in tags:
                recommendations.append(
                    "Water-sign intuition is heightened by rain; make space for emotional insight without spiraling."
                )
            elif "sunny" in tags:
                recommendations.append(
                    "Let sunlight balance sensitivity: move gently, connect with someone safe, and refresh your mood."
                )
            else:
                recommendations.append(
                    "Your water element favors compassion, imagination, and energetic boundaries."
                )
            activity_ideas.append("Practice meditation, music, art, or a restorative bath/shower.")

        # Horoscope text, if available, shapes the final note without pretending to parse all semantics.
        if horoscope_text:
            recommendations.append(
                "Compare today's horoscope message with the weather context; choose the advice that is both inspiring and practical."
            )

        if not wellness_notes:
            wellness_notes.append(
                f"Core theme for {sign.title()} ({element}): {themes['focus']}; watch-out: {themes['watchout']}."
            )

        # Deduplicate while preserving order.
        def unique(items: List[str]) -> List[str]:
            seen = set()
            output = []
            for item in items:
                if item not in seen:
                    seen.add(item)
                    output.append(item)
            return output

        headline = (
            f"{sign.title()} {element.title()} energy meets "
            f"{weather_summary.get('description') or weather_summary.get('condition') or 'current weather'}."
        )

        return {
            "headline": headline,
            "sign": sign,
            "element": element,
            "weather_tags": tags,
            "astrology_theme": themes,
            "horoscope_excerpt": horoscope_text,
            "recommendations": unique(recommendations),
            "activity_ideas": unique(activity_ideas),
            "wellness_notes": unique(wellness_notes),
            "disclaimer": (
                "Astrology insights are for reflection and entertainment. "
                "Weather-related safety guidance should be checked against local official alerts."
            ),
        }


class AstroMeshApp:
    """Facade that coordinates astrology, weather, and insight generation."""

    def __init__(self, config: Optional[AstroMeshConfig] = None):
        self.config = config or AstroMeshConfig.from_env()
        self.astrology = FreeAstrologyClient(self.config)
        self.weather = OpenWeatherClient(self.config)
        self.analyzer = AstroWeatherAnalyzer()

    def close(self) -> None:
        """Close underlying HTTP clients."""
        self.astrology.close()
        self.weather.close()

    def __enter__(self) -> "AstroMeshApp":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def get_birth_chart(self, request: BirthChartRequest) -> Dict[str, Any]:
        """Get a birth chart from Free Astrology API."""
        return self.astrology.birth_chart(request)

    def get_horoscope(self, request: HoroscopeRequest) -> Dict[str, Any]:
        """Get a horoscope from Free Astrology API."""
        return self.astrology.horoscope(request)

    def get_weather(self, request: WeatherRequest) -> Dict[str, Any]:
        """Get current weather from OpenWeatherMap."""
        return self.weather.current_weather(request)

    def get_combined_insights(self, request: CombinedInsightRequest) -> Dict[str, Any]:
        """Get combined astrology + weather insights."""
        sign = request.resolve_sign()
        weather_request = WeatherRequest(
            city=request.city,
            latitude=request.latitude,
            longitude=request.longitude,
            units=request.units,
        )
        horoscope_request = HoroscopeRequest(sign=sign)

        weather = self.get_weather(weather_request)
        horoscope = self.get_horoscope(horoscope_request)
        weather_summary = self.analyzer.summarize_weather(weather, units=request.units)
        recommendation_bundle = self.analyzer.generate_recommendations(
            sign=sign,
            weather_summary=weather_summary,
            horoscope=horoscope,
        )

        result: Dict[str, Any] = {
            "generated_at_utc": datetime.utcnow().isoformat() + "Z",
            "sign": sign,
            "weather": weather_summary,
            "horoscope": horoscope,
            "insights": recommendation_bundle,
        }

        if request.include_birth_chart and request.birth_chart:
            result["birth_chart"] = self.get_birth_chart(request.birth_chart)

        return result


def _print_json(data: Any) -> None:
    print(json.dumps(data, indent=2, ensure_ascii=False, default=str))


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="AstroMesh: combine Free Astrology API and OpenWeatherMap data."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    horoscope = sub.add_parser("horoscope", help="Fetch horoscope by zodiac sign.")
    horoscope.add_argument("--sign", required=True, choices=sorted(ZODIAC_SIGNS))
    horoscope.add_argument("--day", default="today", choices=["yesterday", "today", "tomorrow"])

    weather = sub.add_parser("weather", help="Fetch current weather.")
    weather.add_argument("--city", help="City name, e.g. London or Austin,US.")
    weather.add_argument("--lat", type=float, help="Latitude.")
    weather.add_argument("--lon", type=float, help="Longitude.")
    weather.add_argument("--units", default="metric", choices=["standard", "metric", "imperial"])

    chart = sub.add_parser("birth-chart", help="Fetch natal/birth chart.")
    chart.add_argument("--year", type=int, required=True)
    chart.add_argument("--month", type=int, required=True)
    chart.add_argument("--day", type=int, required=True)
    chart.add_argument("--hours", type=int, required=True)
    chart.add_argument("--minutes", type=int, required=True)
    chart.add_argument("--seconds", type=int, default=0)
    chart.add_argument("--lat", type=float, required=True)
    chart.add_argument("--lon", type=float, required=True)
    chart.add_argument("--timezone", type=float, required=True)
    chart.add_argument("--name")

    insight = sub.add_parser("insight", help="Get combined astrology + weather insight.")
    insight.add_argument("--sign", choices=sorted(ZODIAC_SIGNS))
    insight.add_argument("--city")
    insight.add_argument("--lat", type=float)
    insight.add_argument("--lon", type=float)
    insight.add_argument("--units", default="metric", choices=["standard", "metric", "imperial"])

    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    try:
        with AstroMeshApp() as app:
            if args.command == "horoscope":
                result = app.get_horoscope(HoroscopeRequest(sign=args.sign, day=args.day))
            elif args.command == "weather":
                result = app.get_weather(
                    WeatherRequest(
                        city=args.city,
                        latitude=args.lat,
                        longitude=args.lon,
                        units=args.units,
                    )
                )
            elif args.command == "birth-chart":
                result = app.get_birth_chart(
                    BirthChartRequest(
                        year=args.year,
                        month=args.month,
                        date=args.day,
                        hours=args.hours,
                        minutes=args.minutes,
                        seconds=args.seconds,
                        latitude=args.lat,
                        longitude=args.lon,
                        timezone=args.timezone,
                        name=args.name,
                    )
                )
            elif args.command == "insight":
                result = app.get_combined_insights(
                    CombinedInsightRequest(
                        sign=args.sign,
                        city=args.city,
                        latitude=args.lat,
                        longitude=args.lon,
                        units=args.units,
                    )
                )
            else:
                parser.error("Unknown command")
                return 2

        _print_json(result)
        return 0

    except (AstroMeshError, ValueError) as exc:
        LOGGER.error("%s", exc)
        print(json.dumps({"error": str(exc)}, indent=2), flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
